import numpy as np
import iwc


def test_cross_fitted_g_recovers_shared_drug_response():
    rng = np.random.default_rng(0)
    G, positions = 200, [f"w{i}" for i in range(8)]
    drugs = [f"d{i}" for i in range(6)]
    g_true = {d: rng.normal(0, 1, G) for d in drugs}
    g_true["DMSO"] = np.zeros(G)
    t_true = {w: rng.normal(0, 1, G) for w in positions}
    plates = {}
    for p in range(6):                                   # each plate places every drug at a random position
        perm = rng.permutation(positions)
        keys = drugs + ["DMSO", "DMSO"]
        sig = np.stack([g_true[d] + t_true[w] + rng.normal(0, 0.2, G) for d, w in zip(keys, perm)])
        plates[f"p{p}"] = dict(sig=sig, drug=np.array(keys), pos=np.array(perm))
    dec = iwc.decompose(plates, {"DMSO"}, lam=0.1, n_iter=200)
    g_of, n_other = iwc.cross_fitted_g(plates, dec, {"DMSO"}, min_other=2, lam=0.1)
    est = g_of("p0", "d3")
    assert est is not None
    assert np.corrcoef(est, g_true["d3"])[0, 1] > 0.9
    assert g_of("p0", "DMSO") is None


def test_correct_gt_adds_g_back():
    s = iwc.simulate_screen(n_units=1, seed=7)
    Y1, info = iwc.signature(s["Y"], s["nr_true"])
    Yf, fl = iwc.flag(Y1, info, 3)
    K, G = Y1.shape[1], Y1.shape[3]
    drug, pos = np.array([f"d{k}" for k in range(K)]), np.array([f"w{k}" for k in range(K)])
    g = np.ones(G)
    out = iwc.correct_gt(Yf, info, fl, drug, pos, "p0", lambda p, key: g, lambda w, key: 0, dict(t={}))
    k, c = np.argwhere(~fl[0])[0]
    assert np.allclose(out[0, k, c] - Yf[0, k, c], info["B"][c] * g)
