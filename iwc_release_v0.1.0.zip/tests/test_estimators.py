import numpy as np
import iwc


def _corr(a, b):
    a = a - a.mean(); b = b - b.mean()
    return (a * b).sum() / np.sqrt((a * a).sum() * (b * b).sum())


def _same_well_similarity(R, nr, ref, rng, n=300):
    """Median correlation of two non-responders of the same treated well."""
    D, K, C, _ = R.shape
    out = []
    for _ in range(n):
        d, k = rng.integers(D), rng.integers(K)
        if ref[d, k]:
            continue
        cs = np.where(nr[d, k] & ~np.isnan(R[d, k, :, 0]))[0]
        if len(cs) < 2:
            continue
        a, b = rng.choice(cs, 2, replace=False)
        out.append(_corr(R[d, k, a], R[d, k, b]))
    return np.median(out)


def test_signature_removes_shared_well_effect():
    s = iwc.simulate_screen(seed=1)
    Y, ref, nr = s["Y"], s["ref"], s["nr_true"]
    rng = np.random.default_rng(0)
    before = _same_well_similarity(iwc.contrast(Y, ref), nr, ref, rng)
    Y1, info = iwc.signature(Y, nr)
    Y1, _ = iwc.flag(Y1, info, 3)
    after = _same_well_similarity(iwc.treated_median_reference(Y1, ref), nr, ref, rng)
    assert before > 0.5
    assert abs(after) < 0.15


def test_well_mean_matches_signature_without_responders():
    s = iwc.simulate_screen(resp_share=0.0, seed=2)
    Y, ref = s["Y"], s["ref"]
    rng = np.random.default_rng(0)
    nr = np.ones(Y.shape[:3], bool)
    a = _same_well_similarity(iwc.treated_median_reference(iwc.well_mean(Y), ref), nr, ref, rng)
    assert abs(a) < 0.15


def test_signature_keeps_responses():
    s = iwc.simulate_screen(seed=3)
    Y, ref, nr, tau = s["Y"], s["ref"], s["nr_true"], s["tau"]
    Y1, info = iwc.signature(Y, nr)
    R = iwc.treated_median_reference(Y1, ref)
    R0 = iwc.treated_median_reference(Y, ref)
    d, k, c = np.where(~nr)
    err1 = np.median([np.linalg.norm(R[i, j, l] - tau[i, j, l]) for i, j, l in zip(d, k, c)])
    err0 = np.median([np.linalg.norm(R0[i, j, l] - tau[i, j, l]) for i, j, l in zip(d, k, c)])
    assert err1 < err0


def test_flags_wells_without_internal_controls():
    s = iwc.simulate_screen(all_respond=(5, 6), seed=4)
    Y1, info = iwc.signature(s["Y"], s["nr_true"])
    Yf, fl = iwc.flag(Y1, info, 3)
    assert fl[:, 5].all() and fl[:, 6].all()
    assert np.isnan(Yf[:, 5, :, 0]).all()
    assert not fl[:, 10].all()


def test_discover_responders_runs_and_finds_most():
    s = iwc.simulate_screen(seed=5, response_sd=3.0)
    nr = iwc.discover_responders(s["Y"], s["ref"])
    truth = ~s["nr_true"] & ~s["ref"][..., None]
    found = (~nr & truth).sum() / truth.sum()
    assert found > 0.7


def test_correct_wrapper():
    s = iwc.simulate_screen(seed=6)
    Y1, info = iwc.correct(s["Y"], s["ref"], nr=s["nr_true"], min_controls=4)
    assert "flags" in info and Y1.shape == s["Y"].shape
    Y2, _ = iwc.correct(s["Y"], s["ref"], method="well_mean")
    assert Y2.shape == s["Y"].shape
