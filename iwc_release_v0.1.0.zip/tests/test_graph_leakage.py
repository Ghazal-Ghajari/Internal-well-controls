import numpy as np
import iwc


def test_fixed_layout_is_not_identifiable():
    # every drug always at its own position, controls at their own positions (as in Parse)
    edges = [(f"d{i}", f"w{i}") for i in range(10) for _ in range(3)] + [("DMSO", "H11"), ("DMSO", "H12")]
    out = iwc.summarize_layout(edges, {"DMSO"})
    assert out["share_linked"] == 0.0 and np.isinf(out["median_R"])


def test_series_resistance():
    # DMSO - w1 - d1 - w2 - d2 : unit resistors in series
    edges = [("DMSO", "w1"), ("d1", "w1"), ("d1", "w2"), ("d2", "w2")]
    drugs, pos, nid, A, anchors = iwc.drug_position_graph(edges, {"DMSO"})
    R, ncomp = iwc.resistance_to_anchors(A, anchors)
    assert ncomp == 1
    assert np.isclose(R[nid[("d", "d1")]], 2.0) and np.isclose(R[nid[("d", "d2")]], 4.0)


def test_parallel_wells_halve_resistance():
    edges = [("DMSO", "w1"), ("d1", "w1"), ("DMSO", "w1"), ("d1", "w1")]
    drugs, pos, nid, A, anchors = iwc.drug_position_graph(edges, {"DMSO"})
    R, _ = iwc.resistance_to_anchors(A, anchors)
    assert np.isclose(R[nid[("d", "d1")]], 1.0)


def test_variance_formula_least_squares():
    # Proposition 2(ii): Var(g_hat) = sigma^2 * R for least squares without shrinkage (lam = 0)
    rng = np.random.default_rng(0)
    layout = [("DMSO", "A"), ("d1", "A"), ("d1", "B"), ("d2", "B"), ("d2", "C"), ("d3", "C"), ("d3", "A"),
              ("DMSO", "B")]
    g_true = {"DMSO": 0.0, "d1": 1.0, "d2": -0.5, "d3": 0.3}
    t_true = {"A": 0.2, "B": -0.4, "C": 0.7}
    est = []
    for _ in range(400):
        sig = np.array([[g_true[d] + t_true[w] + rng.normal()] for d, w in layout])
        plates = {"p": dict(sig=sig, drug=np.array([d for d, _ in layout]), pos=np.array([w for _, w in layout]))}
        dec = iwc.decompose(plates, {"DMSO"}, lam=0.0, n_iter=500)
        est.append(dec["g"]["d2"][0])
    drugs, pos, nid, A, anchors = iwc.drug_position_graph(layout, {"DMSO"})
    R, _ = iwc.resistance_to_anchors(A, anchors)
    assert abs(np.mean(est) - g_true["d2"]) < 0.15
    assert 0.75 < np.var(est) / R[nid[("d", "d2")]] < 1.3


def test_leakage_formula_against_monte_carlo():
    rng = np.random.default_rng(1)
    n, m, G = 6, 2, 20000
    r = rng.normal(0, 1.0, (m, G))                     # unrelated responses (kappa ~ 0)
    eps = rng.normal(0, 1.0, (n, G))
    y = eps.copy(); y[:m] += r                         # cell types 0..m-1 respond
    c = n - 1
    tilde = y[c] - y[np.arange(n) != c].mean(0)       # well mean correction of non-responder c
    rbar = r.mean(0)
    d = rbar + rng.normal(0, 0.5, G)                   # independent estimate of rbar
    obs = np.corrcoef(tilde, d)[0, 1]
    eta = eps[c] - eps[np.arange(n) != c].mean(0)
    pred = iwc.predicted_leakage(n, m, np.linalg.norm(rbar), np.linalg.norm(eta),
                                 rho_d=np.dot(rbar, d) / np.linalg.norm(rbar) / np.linalg.norm(d))
    assert abs(obs - pred) < 0.03
    assert np.isclose(iwc.mean_response_norm(2.0, 4, 0.0) ** 2, 0.5)
