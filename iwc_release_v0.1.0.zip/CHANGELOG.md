# Changelog

## 0.1.0 (2026-10-30)

First release of the `iwc` package, extracted from the analysis notebooks of the paper.

- `iwc.well_mean`, `iwc.signature`, `iwc.flag`, `iwc.correct`: within-well estimators (leave-one-out well mean;
  signature from the other non-responders with per-gene slopes; flags for entries with too few internal controls).
- `iwc.discover_responders`: responder calls within each unit, refined with a low-rank well effect.
- `iwc.decompose`, `iwc.cross_fitted_g`, `iwc.correct_gt`: separation of a shared drug response from the position
  effect across plates, with cross-fitting.
- `iwc.drug_position_graph`, `iwc.resistance_to_anchors`, `iwc.summarize_layout`: identifiability of a layout
  (connectedness to the controls, effective resistance).
- `iwc.predicted_leakage`, `iwc.mean_response_norm`: leakage of the well mean.
- `iwc.simulate_screen` and tests (pytest), run on GitHub Actions.
