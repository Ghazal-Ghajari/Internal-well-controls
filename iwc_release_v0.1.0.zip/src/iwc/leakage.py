"""Leakage of a response into the internal controls of a well under the well mean (Proposition 1 of the paper).

A well has n observed cell types, m of which respond with responses r_j. The well mean gives a non-responder c
the corrected profile eta_c - a * rbar with a = m / (n - 1). As the number of genes grows,
    corr(corrected_c, d) -> - rho_d * z / sqrt(1 + z^2),   z = a * |rbar| / |eta_c|,   rho_d = cos(rbar, d),
where d is an estimate of rbar from independent data, and |rbar|^2 = qbar^2 * (1/m + (1 - 1/m) * kappa).
"""
import numpy as np


def mean_response_norm(qbar2, m, kappa):
    """|rbar| from the mean squared response size qbar2, the number of responders m and their mean alignment."""
    return float(np.sqrt(qbar2 * (1.0 / m + (1.0 - 1.0 / m) * kappa)))


def predicted_leakage(n, m, rbar_norm, eta_norm, rho_d=1.0):
    """Limit of corr(well-mean-corrected non-responder, d). Negative = the responders' response leaked in."""
    if m == 0:
        return 0.0
    z = (m / (n - 1)) * rbar_norm / eta_norm
    return float(-rho_d * z / np.sqrt(1.0 + z * z))
