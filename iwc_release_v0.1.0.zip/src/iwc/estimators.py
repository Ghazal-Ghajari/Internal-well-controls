"""Within-well estimators: the well mean and the signature estimator (masks, per-gene slopes, flags)."""
import numpy as np


def _obs(Y):
    return ~np.isnan(Y[..., 0])


def centre(Y, ok):
    """Remove each (unit, cell type) mean over the wells in `ok` (all observed wells if none)."""
    D, K, C, G = Y.shape
    Y0 = np.empty_like(Y)
    for d in range(D):
        for c in range(C):
            m = ok[d, :, c]
            Y0[d, :, c] = Y[d, :, c] - (Y[d, m, c].mean(0) if m.any() else np.nanmean(Y[d, :, c], 0))
    return Y0


def contrast(Y1, ref):
    """Response against the reference wells of each unit: Y1[d] - mean(Y1[d, ref[d]])."""
    out = np.empty_like(Y1)
    for d in range(Y1.shape[0]):
        out[d] = Y1[d] - np.nanmean(Y1[d, ref[d]], 0)
    return out


def treated_median_reference(Y1, ref):
    """Response against the median of each cell type over the treated (non-reference) wells of its unit."""
    out = np.empty_like(Y1)
    for d in range(Y1.shape[0]):
        out[d] = Y1[d] - np.nanmedian(Y1[d][~ref[d]], axis=0, keepdims=True)
    return out


# ---------------------------------------------------------------- responder calls
def _fit_shared(Y0, ok, R, n_iter=30, ridge=1e-3):
    U, C, G = Y0.shape
    full = ok.all(1)
    base = Y0[full] if full.sum() > 3 * R else Y0
    _, _, Vt = np.linalg.svd(base.reshape(len(base), C * G), full_matrices=False)
    L = Vt[:R].reshape(R, C, G).transpose(1, 0, 2).copy()
    w = ok.astype(float)
    for _ in range(n_iter):
        Gm = np.einsum("crg,csg->crs", L, L)
        b = np.einsum("crg,ucg->ucr", L, Y0)
        A = np.einsum("uc,crs->urs", w, Gm) + ridge * np.eye(R)
        z = np.linalg.solve(A, np.einsum("uc,ucr->ur", w, b)[..., None])[..., 0]
        for c in range(C):
            m = ok[:, c]
            if m.sum() > R:
                L[c] = np.linalg.lstsq(z[m], Y0[m, c], rcond=None)[0]
    return z, L


def _low_rank(Y, nr, R):
    D, K, C, G = Y.shape
    obs = _obs(Y)
    ok = nr & obs
    Y0f = np.nan_to_num(centre(Y, ok)).reshape(D * K, C, G)
    z, L = _fit_shared(Y0f, ok.reshape(D * K, C), R)
    Y1 = (Y0f - np.einsum("ur,crg->ucg", z, L)).reshape(D, K, C, G)
    Y1[~obs] = np.nan
    return Y1


def _unit_score(Y1u, ref_u):
    r = Y1u - np.nanmean(Y1u[ref_u], 0)
    med = np.nanmedian(r, 0)
    sd = 1.4826 * np.nanmedian(np.abs(r - med), 0) + 1e-3
    return np.nanmean((r / sd) ** 2, -1)


def _nr_rule(sc, ref_u, k):
    med = np.nanmedian(sc, 0)
    mad = 1.4826 * np.nanmedian(np.abs(sc - med), 0)
    nr = sc <= med + k * mad
    nr[ref_u] = True
    return nr


def discover_responders(Y, ref, rank=5, rounds=2, k=3.0):
    """Non-responder mask [D, K, C] (True = does not respond), called within each unit and refined with a
    low-rank well effect, as in the paper. Reference wells are non-responders by definition."""
    nr = np.stack([_nr_rule(_unit_score(Y[d], ref[d]), ref[d], k) for d in range(len(Y))])
    for _ in range(rounds):
        Y1 = _low_rank(Y, nr, rank)
        nr = np.stack([_nr_rule(_unit_score(Y1[d], ref[d]), ref[d], k) for d in range(len(Y))])
    return nr


# ---------------------------------------------------------------- estimators
def well_mean(Y):
    """Leave-one-out mean of the other observed cell types of the well, slope one, no masks, no flags."""
    obs = _obs(Y)
    Y0 = np.nan_to_num(centre(Y, obs))
    okf = obs.astype(np.float32)
    S = np.einsum("dkc,dkcg->dkg", okf, Y0)
    n_other = okf.sum(-1)[..., None] - okf
    P = (S[:, :, None, :] - okf[..., None] * Y0) / np.maximum(n_other, 1)[..., None]
    P[n_other == 0] = 0
    Y1 = Y0 - P
    Y1[~obs] = np.nan
    return Y1


def signature(Y, nr, ridge=1e-2):
    """Signature estimator: for each entry, the mean centred profile of the OTHER non-responders of its well,
    removed with a per-gene slope per cell type. Returns the corrected array (not yet flagged) and an info dict
    (Y0 centred data, ok mask, slopes B [C, G], predicted signature P, n_other = number of internal controls)."""
    obs = _obs(Y)
    ok = nr & obs
    Y0 = np.nan_to_num(centre(Y, ok))
    okf = ok.astype(np.float32)
    S = np.einsum("dkc,dkcg->dkg", okf, Y0)
    n_other = okf.sum(-1)[..., None] - okf
    P = (S[:, :, None, :] - okf[..., None] * Y0) / np.maximum(n_other, 1)[..., None]
    P[n_other == 0] = 0
    w = okf[..., None]
    B = (w * P * Y0).sum((0, 1)) / ((w * P * P).sum((0, 1)) + ridge)
    Y1 = Y0 - B[None, None] * P
    Y1[~obs] = np.nan
    return Y1, dict(Y0=Y0, ok=ok, B=B, P=P, n_other=n_other)


def flag(Y1, info, min_controls):
    """Set entries with fewer than `min_controls` internal controls to NaN. Returns (flagged array, flag mask)."""
    fl = info["n_other"] < min_controls
    out = Y1.copy()
    out[fl] = np.nan
    return out, fl


def correct(Y, ref, method="signature", min_controls=5, nr=None, **kw):
    """One call: 'well_mean' or 'signature' (responders called if `nr` is None). Returns (corrected, info)."""
    if method == "well_mean":
        return well_mean(Y), {}
    if method != "signature":
        raise ValueError("method must be 'signature' or 'well_mean'")
    nr = discover_responders(Y, ref, **kw) if nr is None else nr
    Y1, info = signature(Y, nr)
    Y1, fl = flag(Y1, info, min_controls)
    info.update(nr=nr, flags=fl)
    return Y1, info
