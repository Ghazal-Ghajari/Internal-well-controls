"""Internal well controls: separate a shared well effect from perturbation responses in multiplexed screens.

Arrays follow the notebooks of the paper: Y has shape [D, K, C, G] (unit = donor or plate, well, cell type or
cell line, gene) and holds log-scale pseudobulk profiles; missing (well, cell type) entries are NaN.
"""
from .estimators import (centre, contrast, treated_median_reference, discover_responders, well_mean,
                         signature, flag, correct)
from .decompose import well_signatures, decompose, cross_fitted_g, correct_gt
from .graph import drug_position_graph, resistance_to_anchors, summarize_layout
from .leakage import mean_response_norm, predicted_leakage
from .simulate import simulate_screen

__version__ = "0.1.0"
__all__ = ["centre", "contrast", "treated_median_reference", "discover_responders", "well_mean", "signature",
           "flag", "correct", "well_signatures", "decompose", "cross_fitted_g", "correct_gt",
           "drug_position_graph", "resistance_to_anchors", "summarize_layout", "mean_response_norm",
           "predicted_leakage", "simulate_screen", "__version__"]
