"""A small simulator of one plate-based screen with a full gene-level well signature, used by the tests."""
import numpy as np


def simulate_screen(n_units=3, n_wells=24, n_types=12, n_genes=300, n_ref=2, resp_share=0.15, all_respond=(),
                    signature_sd=1.0, response_sd=1.5, noise_sd=0.5, seed=0):
    """Returns dict(Y [D,K,C,G], ref [D,K], nr_true [D,K,C], tau [D,K,C,G], sig [K,G]).
    The well signature depends only on the position (the same on every unit, as with a fixed layout),
    each cell type feels it with its own per-gene slope, and responders get an independent response.
    Wells listed in `all_respond` have every cell type responding (no internal control)."""
    rng = np.random.default_rng(seed)
    D, K, C, G = n_units, n_wells, n_types, n_genes
    sig = rng.normal(0, signature_sd, (K, G))
    slope = rng.uniform(0.6, 1.4, (C, G))
    base = rng.normal(0, 1, (C, G))
    ref = np.zeros((D, K), bool)
    ref[:, :n_ref] = True
    nr = rng.random((D, K, C)) > resp_share
    for k in all_respond:
        nr[:, k] = False
    nr[ref] = True
    tau = np.where(~nr[..., None], rng.normal(0, response_sd, (D, K, C, G)), 0.0)
    Y = base[None, None] + slope[None, None] * sig[None, :, None] + tau + rng.normal(0, noise_sd, (D, K, C, G))
    return dict(Y=Y.astype(np.float64), ref=ref, nr_true=nr, tau=tau, sig=sig)
