"""Separate a shared drug response g from the position effect t across plates: s_pk = g_drug + t_pos + e."""
import numpy as np


def well_signatures(info, min_controls):
    """[K, G] mean centred profile of the non-responders of each well of the first unit (NaN if too few)."""
    ok, Y0 = info["ok"][0], info["Y0"][0]
    n = ok.sum(1)
    S = (Y0 * ok[..., None]).sum(1) / np.maximum(n, 1)[:, None]
    S[n < min_controls] = np.nan
    return S


def decompose(plates, ref_keys, lam=1.0, n_iter=30):
    """Alternating least squares with ridge shrinkage `lam` (in wells).

    plates: {plate: dict(sig=[K, G] signatures (NaN rows skipped), drug=[K] keys, pos=[K] positions)}.
    ref_keys: drug keys of the control wells (g = 0, the anchors).
    Returns dict(g={key: [G]}, t={pos: [G]}, n_pos={pos: wells}, ident={key: bool}) where ident says whether the
    drug ever shares a position with another drug (necessary, not sufficient, for identification; see graph.py)."""
    U = [(p, k) for p in plates for k in range(len(plates[p]["sig"])) if not np.isnan(plates[p]["sig"][k, 0])]
    X = np.stack([plates[p]["sig"][k] for p, k in U])
    dk = np.array([plates[p]["drug"][k] for p, k in U])
    pk = np.array([plates[p]["pos"][k] for p, k in U])
    du, di = np.unique(dk, return_inverse=True)
    pu, pi = np.unique(pk, return_inverse=True)
    is_ref = np.isin(du, list(ref_keys))
    nd = np.bincount(di, minlength=len(du))[:, None]
    npos = np.bincount(pi, minlength=len(pu))[:, None]
    g, t = np.zeros((len(du), X.shape[1])), np.zeros((len(pu), X.shape[1]))
    for _ in range(n_iter):
        g = np.zeros_like(g); np.add.at(g, di, X - t[pi]); g /= nd + lam; g[is_ref] = 0
        t = np.zeros_like(t); np.add.at(t, pi, X - g[di]); t /= npos + lam
    keys_at = {w: set(dk[pk == w]) for w in pu}
    ident = {d: any(len(keys_at[w] - {d}) > 0 for w in set(pk[dk == d])) for d in du}
    return dict(g=dict(zip(du, g)), t=dict(zip(pu, t)), n_pos=dict(zip(pu, npos[:, 0])), ident=ident)


def cross_fitted_g(plates, dec, ref_keys, min_other=3, lam=1.0):
    """g of a drug for plate p, estimated only from its wells on OTHER plates at positions that hold at least
    `min_other` other drugs. Returns (g_of(p, key) -> [G] or None, n_other(pos, key) -> int)."""
    at = {}
    for q in plates:
        for j in range(len(plates[q]["sig"])):
            if not np.isnan(plates[q]["sig"][j, 0]):
                at.setdefault(plates[q]["pos"][j], []).append(plates[q]["drug"][j])

    def n_other(w, key):
        return sum(x != key for x in at.get(w, []))

    def g_of(p, key):
        if key in ref_keys:
            return None
        vals = [plates[q]["sig"][j] - dec["t"][plates[q]["pos"][j]]
                for q in plates if q != p for j in np.where(np.asarray(plates[q]["drug"]) == key)[0]
                if not np.isnan(plates[q]["sig"][j, 0]) and n_other(plates[q]["pos"][j], key) >= min_other]
        return np.sum(vals, 0) / (len(vals) + lam) if vals else None
    return g_of, n_other


def correct_gt(Y1_flagged, info, flags, drug, pos, plate, g_of, n_other, dec, min_other=3):
    """Two-stage correction of one plate (unit 0): unflagged entries get g added back (B_c * g); flagged
    entries are corrected from the position effect t when the position holds enough other drugs."""
    Y1 = Y1_flagged.copy()
    B, Y0 = info["B"], info["Y0"]
    for k in range(Y1.shape[1]):
        gk = g_of(plate, drug[k])
        tk = dec["t"].get(pos[k]) if n_other(pos[k], drug[k]) >= min_other else None
        for c in range(Y1.shape[2]):
            if flags[0, k, c]:
                if tk is not None:
                    Y1[0, k, c] = Y0[0, k, c] - B[c] * tk
            elif gk is not None and not np.isnan(Y1[0, k, c, 0]):
                Y1[0, k, c] = Y1[0, k, c] + B[c] * gk
    return Y1
