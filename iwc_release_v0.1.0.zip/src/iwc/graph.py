"""Drug-position graph: connectedness to the controls and effective resistance (Proposition 2 of the paper).

Nodes are drugs and positions; every well (a drug at a position on some plate) is a unit resistor; control drugs
are anchors (merged into one ground). Without noise, g and t are identified iff every component has an anchor;
with independent residuals of variance sigma^2, Var(g_d) = sigma^2 * R(d) for least squares without shrinkage.
"""
import numpy as np
from scipy.sparse.csgraph import connected_components


def drug_position_graph(edges, ref_keys):
    """edges: iterable of (drug_key, position). Returns (drugs, positions, node index, adjacency, anchor ids)."""
    edges = list(edges)
    drugs = sorted({d for d, _ in edges}, key=str)
    pos = sorted({w for _, w in edges}, key=str)
    nid = {("d", d): i for i, d in enumerate(drugs)}
    nid.update({("w", w): len(drugs) + i for i, w in enumerate(pos)})
    A = np.zeros((len(nid), len(nid)))
    for d, w in edges:
        i, j = nid[("d", d)], nid[("w", w)]
        A[i, j] += 1
        A[j, i] += 1
    anchors = [nid[("d", d)] for d in drugs if d in set(ref_keys)]
    return drugs, pos, nid, A, anchors


def resistance_to_anchors(A, anchors):
    """Effective resistance of every node to the anchors (inf where the component has no anchor).
    Returns (R per node, number of connected components)."""
    ncomp, lab = connected_components(A > 0, directed=False)
    anchors = list(anchors)
    ok_comp = {lab[a] for a in anchors}
    aset = set(anchors)
    idx = [i for i in range(len(A)) if i not in aset and lab[i] in ok_comp]
    L = np.diag(A.sum(1)) - A
    R = np.full(len(A), np.inf)
    if idx:
        R[idx] = np.diag(np.linalg.inv(L[np.ix_(idx, idx)]))
    R[anchors] = 0.0
    return R, ncomp


def summarize_layout(edges, ref_keys):
    """Components, share of non-control drugs linked to a control, median and 90th percentile resistance."""
    drugs, pos, nid, A, anchors = drug_position_graph(edges, ref_keys)
    R, ncomp = resistance_to_anchors(A, anchors)
    Rd = np.array([R[nid[("d", d)]] for d in drugs if d not in set(ref_keys)])
    fin = np.isfinite(Rd)
    return dict(drugs=len(drugs), positions=len(pos), components=ncomp,
                share_linked=float(fin.mean()) if len(Rd) else np.nan,
                median_R=float(np.median(Rd[fin])) if fin.any() else np.inf,
                p90_R=float(np.quantile(Rd[fin], 0.9)) if fin.any() else np.inf)
